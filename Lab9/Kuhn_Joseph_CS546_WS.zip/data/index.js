const primeCheck = require("./primeCheck");

module.exports = {
  primeCheck: primeCheck
};