const mongoCollections = require("./collections");
const posts = mongoCollections.posts;
const animals = require("./animals");
const uuid = require("node-uuid");

module.exports = {
    async addPost(title, author, content) {
        if (!title || typeof title != "string") 
        { 
            throw "You must provide a title for your post in the form of a string";
        }
        if (!author || typeof author != "string")
        {
          throw "You must provide an author for your post in the form of a string";
        }
        if (!content || typeof content != "string")
        {
          throw "You must provide content for your post in the form of a string";
        }
        const postCollection = await posts();
    
        let newPost = {
          title: title,
          author: author,
          content: content
        };
    
        const insertInfo = await postCollection.insertOne(newPost);
        if (insertInfo.insertedCount === 0) 
        {
            throw "Could not add post"
        }
    
        const newId = insertInfo.insertedId;
        const post = await this.getPostById(newId);

        console.log("working4");
        return post;
    },

    async getPostById(id)
    {
        if (!id) 
        {
            throw "You must provide an id to search for"
        }
        const postCollection = await posts();
        console.log("error 2");
        const post = await postCollection.findOne({ _id: mongo.ObjectId(id) });
        console.log("error 3");
        if (post === null)
        {
            console.log("error 4");
            throw "No post exists with that id"
        }
        return post;
    },

    async getPostByTitle(titleName) {
        if (!titleName)
        {
            throw "You must provide an id to search for"
        }
    
        const postCollection = await posts();
        const post = await postCollection.find({ title: titleName }).toArray();
        if (post === null)
        {
            throw "No post exists with that author"
        }
        return post;
      },

      async getPostByAuthor(authorName) {
        if (!authorName)
        {
            throw "You must provide an id to search for"
        }
    
        const postCollection = await posts();
        const post = await postCollection.find({ author: authorName }).toArray();
        if (post === null)
        {
            throw "No post exists with that author"
        }
        return post;
      },

    async getAllPosts() 
    {
        const postCollection = await posts();
        const postsAll = await postCollection.find({}).toArray();
        return postsAll;
    },

  async removeById(id) {
    if (!id)
    {
        throw "You must provide an id to search for";
    }
    const postCollection = await posts();
    const deletionInfo = await postCollection.removeOne({ _id: mongo.ObjectId(id) });
    if (deletionInfo.deletedCount === 0) 
    {
      throw `Could not delete post with id of ${id}`;
    }
  },

  async removeByAuthor(authorId) {
    if (!authorId)
    {
        throw "You must provide an id or string to search for";
    }
    const deletePosts = await this.getByAuthor(authorId);
    for (let x = 0; x < deletePosts.length; i++) 
    {
        await this.remove(deletePosts[x]._id);
    }
  },

  async updateTitle(id, newTitle) {
    if (!id)
    {
    throw "You must provide an id to search for";
    }

    if (!newTitle)
    {
    throw "You must provide a new title for the post";
    }

    const postCollection = await posts();
    const postUpdate = {
        $set: { title: newTitle }
    };
    
    const updatedInfo = await postCollection.updateOne({ _id: mongo.ObjectId(id) }, postUpdate);
    if (updatedInfo.modifiedCount === 0) 
    {
        throw "The post title wasn't changed";
    }

    return await this.getPostById(id);
    },

    async updateContent(id, newContent) {
        if (!id)
        {
        throw "You must provide an id to search for";
        }

        if (!newContent)
        {
        throw "You must provide new content for the post";
        }

        const postCollection = await posts();
        const postUpdate = {
            $set: { content: newContent }
        };
        
        const updatedInfo = await postCollection.updateOne({ _id: mongo.ObjectId(id) }, postUpdate);
        if (updatedInfo.modifiedCount === 0) 
        {
            throw "The post content wasn't changed";
        }

        return await this.getPostById(id);
    }
}
