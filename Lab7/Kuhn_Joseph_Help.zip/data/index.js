const postData = require("./posts");
const animalsData = require("./animals");

module.exports = {
  animals: animalsData,
  posts: postData
};
